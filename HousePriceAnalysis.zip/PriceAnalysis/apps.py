from django.apps import AppConfig


class PriceanalysisConfig(AppConfig):
    name = 'PriceAnalysis'
