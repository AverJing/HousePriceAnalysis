from echarts import models

# Create your models here.