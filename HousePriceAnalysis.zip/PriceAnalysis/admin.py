from django.contrib import admin


# 自己创建的模型 必须手动进行注册
# Register your models here.
