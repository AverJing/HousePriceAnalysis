from django.contrib import admin
from echarts import models
# Register your models here.